package com.mady_dwi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MadyDwiApplicationTests {

	@Test
	void contextLoads() {
	}

}
