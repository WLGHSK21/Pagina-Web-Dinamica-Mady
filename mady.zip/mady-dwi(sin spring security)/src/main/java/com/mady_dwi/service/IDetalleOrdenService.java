package com.mady_dwi.service;

import com.mady_dwi.model.DetalleOrden;

public interface IDetalleOrdenService {
	
	DetalleOrden save (DetalleOrden detalleOrden);
	
}
