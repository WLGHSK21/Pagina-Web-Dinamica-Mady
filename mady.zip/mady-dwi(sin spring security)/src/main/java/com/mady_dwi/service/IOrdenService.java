package com.mady_dwi.service;

import java.util.List;
import java.util.Optional;

import com.mady_dwi.model.Orden;
import com.mady_dwi.model.Usuario;

public interface IOrdenService {

	List<Orden> findAll();

	Optional<Orden> findById(Integer id);

	Orden save(Orden orden);

	String generarNumeroOrden();

	List<Orden> findByUsuario(Usuario usuario);

}
